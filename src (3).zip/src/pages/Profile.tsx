import { ListItemButton } from "@mui/material";

const Products = () => {
    return (
      <div>
        <h1>Profile</h1>
        <ListItemButton/>
      </div>
    );
  };
  
  export default Products;
  