declare module 'leaflet/dist/leaflet.css';
declare module 'react-quill/dist/quill.snow.css';
declare module "react-quill";
declare module "leaflet-geosearch";