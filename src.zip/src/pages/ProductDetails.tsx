const ProductDetails = () => {
  return (
    <div>
      <h1>ProductsDetails</h1>
    </div>
  );
};

export default ProductDetails;
