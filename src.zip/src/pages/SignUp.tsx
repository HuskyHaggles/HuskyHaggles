import SignupPage from "../components/SignupForm";

const SignUp = () => {
    return <SignupPage />;
};

export default SignUp;