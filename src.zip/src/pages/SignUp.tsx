import React from "react";
import SignupPage from "../components/SignupForm";
import { useNavigate } from "react-router-dom";

const SignUp = () => {
    return <SignupPage />;
};

export default SignUp;