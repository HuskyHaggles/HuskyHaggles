import "../App.css";

export default function Footer() {
  return (
    <div>
      <p className="text-blue-200">
        Made by: Jake Leigh, Kenny Chen, Sean Finch, Vitor Prates, and Eric Huang
      </p>
    </div>
  );
}
