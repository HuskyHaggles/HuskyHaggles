import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Users from "./pages/Users";
import Listings from "./pages/Listings";
import ListingDetails from "./pages/ListingDetails";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/users" element={<Users />} />
        <Route path="/listings" element={<Listings />} />
        <Route path="/user/:username" element={<Listings />} />
        <Route
          path="/user/:username/:listing_uuid"
          element={<ListingDetails />}
        />
      </Routes>
    </Router>
  );
}

export default App;
